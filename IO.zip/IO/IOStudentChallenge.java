/**
 * This is a class used to test the student on their IO knowledge
 */
public class IOStudentChallenge {
    
    /**
     * main method
     * @param args
     */
    public static void main(String[] args) {
        // Ask the user how many siblings do they have
        // Store the user's response as an int
        // Print out how many siblings the user has and ask for their names
        // Example: You have 8 siblings! What are their names?
        // Store their response as a String
        // Print out their names back to the user
    }
}
