/**
 * This is a class used to test the student on their Selection Staments knowledge
 */
public class Siblings {
    
    /**
     * main method
     * @param args
     */
    public static void main(String[] args) {
        //Ask the user how many siblings do they have
        //Store the user's response as an int
        //If they don't have any siblings print out "Lucky you!" or something else
        //If the user response is 1, then ask what is their sibling's name and store it in a variable
        //If the user has more than 1 ask for their names
        //Example: You have 8 siblings! What are their names?
        //Store their response as a String
        //Print out their names back to the user and say something about their names
    }
}
